public enum TreeType {
    //OPERAÇÃO ARITMÉTICA
    OPAR,
    //OPERAÇÃO CONDICIONAL
    OPCOND,
}
