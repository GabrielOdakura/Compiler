public class No {


    public Token token;
    public No esq = null;
    public No dir = null;

    public No(No esq,No dir,Token token){
        this.token = token;
        this.esq = esq;
        this.dir = dir;
    }
}

